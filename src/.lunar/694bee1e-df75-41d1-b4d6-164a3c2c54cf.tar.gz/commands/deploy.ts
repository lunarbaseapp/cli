import { Command, flags } from "@oclif/command";
import { createReadStream, existsSync, mkdirSync, PathLike, readFile, readFileSync } from "fs";
import { glob } from "glob";
import * as tar from "tar";
import { v4 } from "uuid";

export default class Deploy extends Command {
  static description = "Deploy a folder to Lunarbase";

  static examples = [
    `$ lunar deploy -f Dockerfile.example ./context

`,
  ];

  static flags = {
    help: flags.help({ char: "h" }),
    // flag with a value (-n, --name=VALUE)
    file: flags.string({
      char: "f",
      description: "Name of the Dockerfile (Default is 'WORKDIR/Dockerfile')",
    }),
  };

  static args = [{ name: "context", default: "." }];

  async run() {
    const { args, flags } = this.parse(Deploy);
    const Dockerfile = readFileSync(flags.file ?? "Dockerfile").toString();
    if (!existsSync(".lunar")) {
      mkdirSync(".lunar");
    }
    this.log(Dockerfile);
    ;(async () => {
      for await (const f of getFiles(args.context)) {
        console.log(f);
      }
    })()
    await tar.create(
      { file: `.lunar/${v4()}.tar.gz` },
      [args.context],
    );
    // const packStream = tar.Pack();
    // packStream.
    // const form = new FormData();
    // form.append()
  }
}

import { resolve } from 'path';
import { promises as fs } from 'fs';

async function* getFiles(dir: string) {
  const dirents = await fs.readdir(dir, { withFileTypes: true });
  for (const dirent of dirents) {
    const res = resolve(dir, dirent.name);
    if (dirent.isDirectory()) {
      yield* getFiles(res);
    } else {
      yield res;
    }
  }
}